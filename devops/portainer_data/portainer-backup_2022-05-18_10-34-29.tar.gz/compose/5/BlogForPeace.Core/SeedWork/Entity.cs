﻿namespace BlogForPeace.Core.SeedWork
{
    public abstract class Entity
    {
        public int Id { get; set; }
    }
}
