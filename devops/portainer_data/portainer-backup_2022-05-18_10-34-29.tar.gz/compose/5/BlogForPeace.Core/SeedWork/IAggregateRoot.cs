﻿namespace BlogForPeace.Core.SeedWork
{
    public interface IAggregateRoot
    {
    }
}
